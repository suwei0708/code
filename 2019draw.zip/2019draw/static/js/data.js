var data=[
    [
        "static/img/i1/item.jpg",
        "static/img/i1/1.png",
        "static/img/i1/2.png",
        "static/img/i1/3.png",
        "static/img/i1/4.png",
        "static/img/i1/5.png",
        "static/img/i1/6.png",
        "static/img/i1/7.png",
        "static/img/i1/8.png",
        "static/img/i1/9.png",
        "static/img/i1/10.png",
        "static/img/i1/11.png"
    ],
    [
        "static/img/i2/item.jpg",
        "static/img/i2/1.png",
        "static/img/i2/2.png",
        "static/img/i2/3.png",
        "static/img/i2/4.png",
        "static/img/i2/5.png",
        "static/img/i2/6.png",
        "static/img/i2/7.png",
        "static/img/i2/8.png",
    ],
    [
        "static/img/i3/item.jpg",
        "static/img/i3/1.png",
        "static/img/i3/2.png",
        "static/img/i3/3.png",
        "static/img/i3/4.png",
        "static/img/i3/5.png",
        "static/img/i3/6.png",
        "static/img/i3/7.png",
        "static/img/i3/8.png",
        "static/img/i3/9.png",
        "static/img/i3/10.png"
    ],
    [
        "static/img/i4/item.jpg",
        "static/img/i4/1.png",
        "static/img/i4/2.png",
        "static/img/i4/3.png",
        "static/img/i4/4.png",
        "static/img/i4/5.png",
        "static/img/i4/6.png",
        "static/img/i4/7.png",
        "static/img/i4/8.png",
        "static/img/i4/9.png",
        "static/img/i4/10.png",
        "static/img/i4/11.png"
    ]
];
var whxyInfo=[
    [
        {
            x: 0,
            y: 0,
            w: 647,
            h: 693
        },
        {
            x: 132,
            y: 551,
            w: 370,
            h: 142
        },
        {
            x:108,
            y:175,
            w:439,
            h:400
        },
        {   //4
            x:475,
            y:217,
            w:30,
            h:33
        },
        {
            x:145,
            y:225,
            w:27,
            h:35
        },
        {
            x:311,
            y:336,
            w:31,
            h:19
        },
        {
            x:194,
            y:294,
            w:73,
            h:58
        },
        {
            x: 390,
            y: 294,
            w: 73,
            h: 60
        },
        {
            x: 221,
            y: 115,
            w: 197,
            h: 95
        },
        {
            x: 232,
            y: 47,
            w: 178,
            h: 93
        },
        {
            x: 290,
            y: 25,
            w: 53,
            h: 31
        }
    ],
    [
        {
            x:0,
            y:0,
            w:647,
            h:693
        },
        {
            x:128,
            y:540,
            w:377,
            h:153
        },
        {
            x:100,
            y:155,
            w:456,
            h:414
        },
        {
            x: 319,
            y: 430,
            w: 23,
            h: 59
        },
        {
            x: 317,
            y: 326,
            w: 28,
            h: 19
        },
        {
            x: 148,
            y: 195,
            w: 32,
            h: 33
        },
        {
            x: 493,
            y: 199,
            w: 34,
            h: 24
        },
        {
            x: 290,
            y: 33,
            w: 110,
            h: 147
        }
    ],
    [
        { //1
            x: 0,
            y: 0,
            w: 647,
            h: 693
        },
        { //2
            x: 96,
            y: 516,
            w: 403,
            h: 177
        },
        { //3
            x: 83,
            y: 145,
            w: 464,
            h: 387
        },
        { //4
            x: 308,
            y: 303,
            w: 26,
            h: 16
        },
        { //5
            x: 97,
            y: 132,
            w: 159,
            h: 152
        },
        { //6
            x: 329,
            y: 131,
            w: 248,
            h: 241
        },
        { //7
            x: 186,
            y: 248,
            w: 80,
            h: 80
        },
        { //8
            x: 384,
            y: 262,
            w: 78,
            h: 63
        },
        { //9
            x: 135,
            y: 190,
            w: 31,
            h: 41
        },
        { //10
            x: 476,
            y: 174,
            w: 31,
            h: 33
        }
    ],
    [
        { //1
            x: 0,
            y: 0,
            w: 647,
            h: 693
        },
        { //2
            x: 121,
            y: 497,
            w: 433,
            h: 196
        },
        { //3
            x: 304,
            y: 537,
            w: 52,
            h: 35
        },
        { //4
            x: 264,
            y: 559,
            w: 149,
            h: 123
        },
        { //5
            x: 98,
            y: 99,
            w: 456,
            h: 438
        },
        { //6
            x: 313,
            y: 296,
            w: 26,
            h: 18
        },
        { //7
            x: 137,
            y: 197,
            w: 23,
            h: 31
        },
        { //8
            x: 473,
            y: 149,
            w: 23,
            h: 23
        },
        { //9
            x: 249,
            y: 150,
            w: 27,
            h: 75
        },
        { //10
            x: 297,
            y: 142,
            w: 27,
            h: 94
        },
        { //11
            x: 344,
            y: 140,
            w: 24,
            h: 79
        }
    ]

];